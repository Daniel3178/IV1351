INSERT INTO renting_system (rent_id,renting_date,student_id)
VALUES
  (1,'Sep 9, 2023',177),
  (2,'May 2, 2023',142),
  (3,'Apr 15, 2023',9),
  (4,'Jul 25, 2023',58),
  (5,'Mar 23, 2023',281),
  (6,'Oct 5, 2023',278),
  (7,'Oct 24, 2023',376),
  (8,'Mar 30, 2023',81),
  (9,'Sep 23, 2023',356),
  (10,'Mar 17, 2023',26);
INSERT INTO renting_system (rent_id,renting_date,student_id)
VALUES
  (11,'Jul 20, 2023',333),
  (12,'Jul 1, 2023',150),
  (13,'May 2, 2023',211),
  (14,'Oct 17, 2023',338),
  (15,'Jan 15, 2023',196),
  (16,'Nov 20, 2022',128),
  (17,'Jul 8, 2023',128),
  (18,'Sep 24, 2023',204),
  (19,'Sep 1, 2023',361),
  (20,'Jan 14, 2023',326);
INSERT INTO renting_system (rent_id,renting_date,student_id)
VALUES
  (21,'Jan 29, 2023',399),
  (22,'Feb 5, 2023',40),
  (23,'Apr 25, 2023',99),
  (24,'May 13, 2023',129),
  (25,'Mar 16, 2023',336),
  (26,'Dec 25, 2022',75),
  (27,'Jul 15, 2023',135),
  (28,'Apr 23, 2023',29),
  (29,'Sep 8, 2023',106),
  (30,'Oct 31, 2023',242);
INSERT INTO renting_system (rent_id,renting_date,student_id)
VALUES
  (31,'Sep 6, 2023',248),
  (32,'Mar 26, 2023',275),
  (33,'Jul 18, 2023',197),
  (34,'Jan 28, 2023',59),
  (35,'May 2, 2023',345),
  (36,'Jan 10, 2023',166),
  (37,'Aug 9, 2023',391),
  (38,'May 24, 2023',190),
  (39,'Nov 11, 2023',182),
  (40,'Mar 31, 2023',218);
INSERT INTO renting_system (rent_id,renting_date,student_id)
VALUES
  (41,'Dec 19, 2022',135),
  (42,'Apr 10, 2023',129),
  (43,'May 11, 2023',188),
  (44,'Nov 30, 2022',165),
  (45,'Sep 11, 2023',155),
  (46,'Jun 10, 2023',32),
  (47,'Aug 22, 2023',203),
  (48,'May 8, 2023',223),
  (49,'Aug 9, 2023',397),
  (50,'Sep 20, 2023',311);
