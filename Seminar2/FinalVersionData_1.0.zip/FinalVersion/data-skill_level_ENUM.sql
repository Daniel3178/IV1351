INSERT INTO skill_level_ENUM (skill_level_id, skill_level)
VALUES  
  (1, "Beginner"),
  (2, "Intermediate"),
  (3, "Advanced");