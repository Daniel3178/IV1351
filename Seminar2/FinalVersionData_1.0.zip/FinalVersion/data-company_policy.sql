INSERT INTO company_policy (selected_value,start_valid_date, end_valid_date,description_id)
VALUES
  (2,'Dec 13, 2022','Dec 13, 2024',1),
  (12,'Dec 13, 2022','Dec 13, 2024',2),
  (0.8,'Dec 13, 2022','Dec 13, 2024',3),