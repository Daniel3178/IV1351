INSERT INTO lesson_type_ENUM (lesson_type_id,lesson_type)
VALUES  
  (1, "Individual"),
  (2, "Ensemble"),
  (3, "Group");
