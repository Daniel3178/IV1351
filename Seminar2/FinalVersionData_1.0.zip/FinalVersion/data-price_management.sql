INSERT INTO price_management (price_id,start_valid_date, end_valid_date, skill_level_id, lesson_type_id)
VALUES
  (1,'Apr 8, 2023','Jan 2, 2024',1,2),
  (2,'Jun 11, 2023','Apr 21, 2024',2,3),
  (3,'Apr 12, 2023','Aug 5, 2024',3,1),
  (4,'Jan 2, 2023','Jan 2, 2024',2,2),
  (5,'Jan 2, 2023','Dec 15, 2024',1,3),
  (6,'Nov 19, 2023','Jan 2, 2024',3,3),
  (7,'Jan 2, 2023','Jan 2, 2024',1,1),
  (8,'Nov 24, 2022','Feb 18, 2024',2,1),
  (9,'Aug 6, 2023','Jan 2, 2024',3,2);
