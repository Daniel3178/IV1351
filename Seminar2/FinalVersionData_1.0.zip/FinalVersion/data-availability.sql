INSERT INTO availability (start_time,availability_date,instructor_id,end_time)
VALUES
('1:37 PM','Aug 9, 2024',92'7:42 PM'),
('1:44 PM','Oct 7, 2024',2'7:45 PM'),
('2:19 PM','Jun 15, 2023',31'7:36 PM'),
('2:48 PM','Aug 2, 2023',32'7:40 PM'),
('1:45 PM','Aug 18, 2023',2'7:37 PM'),
('1:22 PM','Oct 23, 2023',45'7:39 PM'),
('1:04 PM','Apr 20, 2023',54'7:11 PM'),
('2:27 PM','Dec 14, 2023',30'7:21 PM'),
('1:36 PM','Jan 23, 2024',91'7:00 PM'),
('2:24 PM','Aug 14, 2023',80'7:46 PM');
INSERT INTO availability (start_time,availability_date,instructor_id,end_time)
VALUES
('2:00 PM','Sep 2, 2024',82'7:26 PM'),
('2:25 PM','Sep 24, 2024',24'7:38 PM'),
('1:08 PM','Dec 27, 2024',1'7:38 PM'),
('2:21 PM','Aug 29, 2023',74'7:38 PM'),
('2:55 PM','Sep 12, 2023',77'7:39 PM'),
('2:53 PM','Nov 2, 2023',77'7:43 PM'),
('1:33 PM','Jul 21, 2023',75'7:14 PM'),
('1:22 PM','Apr 21, 2024',17'7:19 PM'),
('2:59 PM','May 31, 2024',33'7:08 PM'),
('2:00 PM','Jan 6, 2024',98'7:51 PM');
INSERT INTO availability (start_time,availability_date,instructor_id,end_time)
VALUES
('1:57 PM','May 4, 2024',81'7:30 PM'),
('1:00 PM','Oct 29, 2023',83'7:01 PM'),
('1:19 PM','Jan 13, 2024',22'7:02 PM'),
('2:18 PM','Aug 13, 2024',41'7:53 PM'),
('1:53 PM','Jul 8, 2024',45'7:54 PM'),
('1:29 PM','Jan 8, 2024',73'7:58 PM'),
('2:37 PM','Mar 29, 2023',83'7:48 PM'),
('2:23 PM','Dec 8, 2023',78'7:32 PM'),
('1:44 PM','Jan 21, 2024',43'7:43 PM'),
('2:20 PM','Jun 13, 2024',3'7:37 PM');
INSERT INTO availability (start_time,availability_date,instructor_id,end_time)
VALUES
('1:38 PM','Mar 31, 2024',93'7:25 PM'),
('1:07 PM','Jul 27, 2023',98'7:25 PM'),
('2:11 PM','Apr 29, 2024',51'7:18 PM'),
('2:22 PM','Jan 10, 2025',59'7:47 PM'),
('1:22 PM','Jan 6, 2023',22'7:19 PM'),
('2:23 PM','Oct 30, 2023',49'7:40 PM'),
('1:52 PM','Feb 14, 2025',28'7:49 PM'),
('2:20 PM','Nov 7, 2024',15'7:10 PM'),
('1:20 PM','Oct 9, 2024',51'7:11 PM'),
('1:55 PM','Dec 14, 2024',97'7:17 PM');
INSERT INTO availability (start_time,availability_date,instructor_id,end_time)
VALUES
('2:27 PM','Jan 9, 2025',14'7:35 PM'),
('1:56 PM','Jul 10, 2023',30'7:43 PM'),
('1:21 PM','Oct 27, 2023',64'7:16 PM'),
('1:18 PM','May 10, 2023',80'7:19 PM'),
('1:48 PM','Feb 6, 2025',85'7:02 PM'),
('1:31 PM','Jun 11, 2023',62'7:50 PM'),
('2:34 PM','Sep 14, 2023',87'7:48 PM'),
('1:59 PM','Mar 18, 2023',55'7:07 PM'),
('1:31 PM','Feb 11, 2023',7'7:50 PM'),
('2:31 PM','Jan 25, 2024',45'7:08 PM');
INSERT INTO availability (start_time,availability_date,instructor_id,end_time)
VALUES
('1:18 PM','Dec 15, 2022',38'7:42 PM'),
('1:02 PM','May 13, 2024',72'7:50 PM'),
('1:18 PM','Nov 16, 2024',69'7:28 PM'),
('2:36 PM','May 16, 2023',17'7:01 PM'),
('1:50 PM','May 22, 2024',76'7:41 PM'),
('1:37 PM','Feb 15, 2025',68'7:19 PM'),
('2:40 PM','Dec 23, 2024',49'7:56 PM'),
('2:41 PM','Feb 23, 2025',78'7:39 PM'),
('2:23 PM','Nov 21, 2024',67'7:27 PM'),
('1:54 PM','Jun 15, 2024',12'7:31 PM');
INSERT INTO availability (start_time,availability_date,instructor_id,end_time)
VALUES
  ('1:53 PM','May 12, 2023',21,'7:55 PM'),
  ('1:57 PM','Dec 4, 2023',22,'7:22 PM'),
  ('2:35 PM','Jul 12, 2024',86,'7:42 PM'),
  ('2:31 PM','Jul 21, 2024',97,'7:53 PM'),
  ('1:41 PM','Nov 18, 2023',61,'7:16 PM'),
  ('1:56 PM','May 18, 2023',98,'7:50 PM'),
  ('2:58 PM','May 14, 2023',71,'7:14 PM'),
  ('2:53 PM','Jul 10, 2023',57,'7:01 PM'),
  ('2:51 PM','Mar 5, 2024',42,'7:59 PM'),
  ('1:46 PM','Jun 23, 2023',98,'7:39 PM');
INSERT INTO availability (start_time,availability_date,instructor_id,end_time)
VALUES
  ('1:39 PM','Nov 19, 2024',19,'7:06 PM'),
  ('2:50 PM','Apr 14, 2023',71,'7:05 PM'),
  ('1:06 PM','Apr 28, 2024',79,'7:45 PM'),
  ('1:23 PM','Aug 10, 2024',77,'7:20 PM'),
  ('1:43 PM','Jul 14, 2023',89,'7:55 PM'),
  ('1:59 PM','Oct 21, 2024',70,'7:03 PM'),
  ('1:20 PM','Oct 15, 2024',36,'7:51 PM'),
  ('1:00 PM','Sep 8, 2024',80,'7:25 PM'),
  ('1:18 PM','May 3, 2024',30,'7:10 PM'),
  ('1:38 PM','Oct 18, 2023',47,'7:44 PM');
INSERT INTO availability (start_time,availability_date,instructor_id,end_time)
VALUES
  ('1:21 PM','May 10, 2023',22,'7:56 PM'),
  ('1:25 PM','Sep 27, 2023',93,'7:09 PM'),
  ('1:32 PM','Sep 15, 2024',40,'7:14 PM'),
  ('2:56 PM','Feb 7, 2023',16,'7:07 PM'),
  ('2:33 PM','Jan 5, 2023',18,'7:59 PM'),
  ('2:18 PM','Apr 3, 2023',11,'7:46 PM'),
  ('1:58 PM','Mar 26, 2023',21,'7:07 PM'),
  ('1:55 PM','Nov 25, 2024',71,'7:41 PM'),
  ('1:48 PM','Jan 25, 2023',67,'7:51 PM'),
  ('1:15 PM','Nov 12, 2023',13,'7:55 PM');
INSERT INTO availability (start_time,availability_date,instructor_id,end_time)
VALUES
  ('1:37 PM','Feb 21, 2024',45,'7:07 PM'),
  ('1:09 PM','Mar 19, 2023',56,'7:47 PM'),
  ('1:20 PM','Jan 24, 2024',33,'7:02 PM'),
  ('2:41 PM','Sep 6, 2024',46,'7:33 PM'),
  ('1:31 PM','Mar 29, 2024',6,'7:55 PM'),
  ('1:25 PM','Apr 25, 2024',83,'7:16 PM'),
  ('2:01 PM','Feb 21, 2024',16,'7:26 PM'),
  ('1:42 PM','Aug 26, 2023',71,'7:22 PM'),
  ('1:05 PM','Apr 15, 2024',64,'7:26 PM'),
  ('2:26 PM','Jan 15, 2025',76,'7:30 PM');
INSERT INTO availability (start_time,availability_date,instructor_id,end_time)
VALUES
  ('1:09 PM','Oct 8, 2023',12,'7:20 PM'),
  ('1:52 PM','Feb 26, 2025',41,'7:47 PM'),
  ('1:17 PM','Jun 6, 2023',68,'7:41 PM'),
  ('1:50 PM','Nov 30, 2022',45,'7:23 PM'),
  ('1:47 PM','Aug 18, 2024',98,'7:02 PM'),
  ('2:37 PM','May 25, 2024',10,'7:33 PM'),
  ('1:07 PM','Apr 7, 2023',56,'7:17 PM'),
  ('2:09 PM','Apr 27, 2024',78,'7:19 PM'),
  ('2:40 PM','Apr 18, 2023',24,'7:14 PM'),
  ('2:39 PM','Jun 17, 2023',62,'7:36 PM');
INSERT INTO availability (start_time,availability_date,instructor_id,end_time)
VALUES
  ('1:00 PM','May 13, 2023',93,'7:31 PM'),
  ('2:05 PM','May 17, 2023',24,'7:45 PM'),
  ('1:06 PM','Apr 16, 2024',39,'7:28 PM'),
  ('2:59 PM','Nov 25, 2024',93,'7:40 PM'),
  ('1:53 PM','Feb 22, 2023',56,'7:48 PM'),
  ('1:29 PM','May 30, 2024',56,'7:22 PM'),
  ('1:12 PM','Jan 18, 2023',52,'7:21 PM'),
  ('1:36 PM','Nov 18, 2023',72,'7:49 PM'),
  ('2:44 PM','Feb 23, 2024',41,'7:32 PM'),
  ('1:06 PM','Nov 22, 2023',22,'7:04 PM');
INSERT INTO availability (start_time,availability_date,instructor_id,end_time)
VALUES
  ('2:03 PM','Dec 15, 2022',13,'7:32 PM'),
  ('2:31 PM','Oct 28, 2024',35,'7:29 PM'),
  ('1:34 PM','Jan 29, 2025',2,'7:04 PM'),
  ('2:06 PM','Sep 15, 2023',90,'7:30 PM'),
  ('1:15 PM','Sep 9, 2024',76,'7:38 PM'),
  ('1:31 PM','Oct 1, 2023',74,'7:52 PM'),
  ('1:08 PM','Jan 22, 2025',15,'7:03 PM'),
  ('1:55 PM','Jul 2, 2024',21,'7:25 PM'),
  ('1:57 PM','Sep 28, 2023',65,'7:55 PM'),
  ('2:02 PM','Oct 13, 2023',45,'7:35 PM');
INSERT INTO availability (start_time,availability_date,instructor_id,end_time)
VALUES
  ('1:02 PM','Dec 25, 2023',82,'7:15 PM'),
  ('2:30 PM','Mar 4, 2023',91,'7:48 PM'),
  ('2:55 PM','Oct 10, 2023',17,'7:57 PM'),
  ('1:46 PM','Dec 17, 2023',48,'7:56 PM'),
  ('2:50 PM','Feb 11, 2024',62,'7:26 PM'),
  ('1:00 PM','Jan 8, 2025',3,'7:29 PM'),
  ('1:52 PM','May 14, 2024',59,'7:50 PM'),
  ('2:05 PM','Dec 26, 2024',40,'7:11 PM'),
  ('1:55 PM','Jul 22, 2024',82,'7:12 PM'),
  ('2:44 PM','May 1, 2023',34,'7:45 PM');
INSERT INTO availability (start_time,availability_date,instructor_id,end_time)
VALUES
  ('2:35 PM','Aug 15, 2023',81,'7:44 PM'),
  ('2:23 PM','Jan 14, 2023',26,'7:43 PM'),
  ('2:11 PM','Nov 7, 2023',88,'7:52 PM'),
  ('1:49 PM','Aug 19, 2024',22,'7:20 PM'),
  ('2:48 PM','Jan 5, 2024',76,'7:40 PM'),
  ('2:04 PM','Jan 6, 2023',33,'7:40 PM'),
  ('1:49 PM','May 22, 2023',70,'7:26 PM'),
  ('1:33 PM','Jul 12, 2024',61,'7:58 PM'),
  ('1:01 PM','Sep 10, 2024',26,'7:24 PM'),
  ('2:02 PM','Jan 9, 2025',32,'7:07 PM');
INSERT INTO availability (start_time,availability_date,instructor_id,end_time)
VALUES
  ('2:13 PM','Mar 24, 2023',21,'7:50 PM'),
  ('1:09 PM','Jan 8, 2023',73,'7:46 PM'),
  ('1:37 PM','Jan 22, 2025',59,'7:31 PM'),
  ('2:52 PM','Jul 3, 2024',11,'7:07 PM'),
  ('2:16 PM','Nov 12, 2024',47,'7:32 PM'),
  ('2:36 PM','Oct 8, 2023',28,'7:17 PM'),
  ('2:58 PM','Dec 11, 2022',23,'7:55 PM'),
  ('1:38 PM','Jul 3, 2024',97,'7:58 PM'),
  ('2:11 PM','Nov 15, 2023',53,'7:28 PM'),
  ('1:41 PM','May 31, 2024',62,'7:52 PM');
INSERT INTO availability (start_time,availability_date,instructor_id,end_time)
VALUES
  ('1:10 PM','Jan 9, 2023',25,'7:57 PM'),
  ('2:58 PM','Feb 10, 2025',8,'7:06 PM'),
  ('2:47 PM','Jul 15, 2023',48,'7:38 PM'),
  ('2:57 PM','Oct 10, 2024',6,'7:27 PM'),
  ('2:20 PM','Sep 28, 2023',35,'7:17 PM'),
  ('2:05 PM','Mar 3, 2024',8,'7:35 PM'),
  ('1:38 PM','Feb 16, 2024',68,'7:20 PM'),
  ('1:11 PM','Nov 26, 2024',37,'7:58 PM'),
  ('2:47 PM','Feb 2, 2023',52,'7:45 PM'),
  ('2:42 PM','Sep 5, 2024',17,'7:47 PM');
INSERT INTO availability (start_time,availability_date,instructor_id,end_time)
VALUES
  ('1:46 PM','Dec 2, 2024',57,'7:56 PM'),
  ('1:11 PM','Sep 11, 2024',45,'7:38 PM'),
  ('1:08 PM','Feb 19, 2023',9,'7:48 PM'),
  ('2:34 PM','Mar 2, 2023',57,'7:54 PM'),
  ('2:07 PM','Nov 8, 2024',71,'7:28 PM'),
  ('2:35 PM','Jun 3, 2024',59,'7:02 PM'),
  ('2:51 PM','Jun 16, 2024',59,'7:01 PM'),
  ('1:54 PM','Feb 28, 2025',7,'7:08 PM'),
  ('2:55 PM','Aug 1, 2023',35,'7:30 PM'),
  ('1:43 PM','Apr 5, 2023',48,'7:13 PM');
INSERT INTO availability (start_time,availability_date,instructor_id,end_time)
VALUES
  ('2:33 PM','May 30, 2023',50,'7:50 PM'),
  ('1:56 PM','Apr 20, 2023',64,'7:02 PM'),
  ('2:52 PM','Feb 2, 2023',59,'7:40 PM'),
  ('2:44 PM','Nov 21, 2022',95,'7:32 PM'),
  ('2:53 PM','Jun 4, 2024',53,'7:05 PM'),
  ('2:51 PM','May 31, 2023',5,'7:09 PM'),
  ('2:02 PM','May 11, 2023',64,'7:09 PM'),
  ('1:32 PM','Feb 25, 2024',50,'7:43 PM'),
  ('1:25 PM','Apr 24, 2023',52,'7:10 PM'),
  ('2:08 PM','May 21, 2024',27,'7:38 PM');
INSERT INTO availability (start_time,availability_date,instructor_id,end_time)
VALUES
  ('1:25 PM','Aug 30, 2023',78,'7:36 PM'),
  ('1:33 PM','May 5, 2023',76,'7:15 PM'),
  ('1:38 PM','Aug 19, 2024',6,'7:29 PM'),
  ('1:56 PM','Mar 14, 2023',91,'7:20 PM'),
  ('2:16 PM','Oct 9, 2023',39,'7:52 PM'),
  ('1:47 PM','Mar 10, 2023',46,'7:29 PM'),
  ('2:48 PM','Dec 20, 2023',91,'7:21 PM'),
  ('1:56 PM','Oct 27, 2024',31,'7:27 PM'),
  ('2:54 PM','Jun 8, 2023',68,'7:51 PM'),
  ('2:00 PM','Aug 30, 2024',91,'7:47 PM');
INSERT INTO availability (start_time,availability_date,instructor_id,end_time)
VALUES
  ('1:51 PM','Mar 21, 2023',8,'7:49 PM'),
  ('1:26 PM','Feb 14, 2025',79,'7:38 PM'),
  ('1:26 PM','Mar 6, 2023',75,'7:55 PM'),
  ('2:50 PM','Oct 27, 2023',31,'7:01 PM'),
  ('2:23 PM','Jul 31, 2023',24,'7:32 PM'),
  ('1:58 PM','Nov 21, 2022',73,'7:30 PM'),
  ('1:44 PM','Jul 10, 2023',69,'7:40 PM'),
  ('1:15 PM','Jul 31, 2024',37,'7:23 PM'),
  ('2:36 PM','Jan 6, 2024',78,'7:39 PM'),
  ('2:01 PM','Feb 8, 2024',77,'7:01 PM');
INSERT INTO availability (start_time,availability_date,instructor_id,end_time)
VALUES
  ('1:52 PM','Sep 30, 2023',21,'7:44 PM'),
  ('1:53 PM','Oct 16, 2024',1,'7:55 PM'),
  ('1:33 PM','Jul 16, 2023',61,'7:17 PM'),
  ('1:08 PM','Oct 21, 2024',52,'7:34 PM'),
  ('2:19 PM','Dec 5, 2022',72,'7:45 PM'),
  ('1:17 PM','Oct 24, 2024',4,'7:27 PM'),
  ('2:12 PM','Sep 5, 2024',90,'7:00 PM'),
  ('1:31 PM','Jan 18, 2024',25,'7:25 PM'),
  ('2:17 PM','Oct 18, 2023',25,'7:32 PM'),
  ('2:25 PM','Feb 12, 2023',84,'7:30 PM');
INSERT INTO availability (start_time,availability_date,instructor_id,end_time)
VALUES
  ('1:48 PM','Aug 31, 2023',41,'7:45 PM'),
  ('1:01 PM','Jan 31, 2024',35,'7:13 PM'),
  ('1:14 PM','Feb 19, 2023',79,'7:19 PM'),
  ('2:16 PM','Jul 17, 2023',27,'7:59 PM'),
  ('1:59 PM','Aug 16, 2023',2,'7:15 PM'),
  ('2:00 PM','Sep 15, 2024',96,'7:23 PM'),
  ('2:54 PM','Nov 17, 2023',18,'7:14 PM'),
  ('2:17 PM','Dec 10, 2024',37,'7:50 PM'),
  ('2:28 PM','Feb 12, 2023',38,'7:46 PM'),
  ('2:42 PM','Nov 30, 2022',23,'7:47 PM');
INSERT INTO availability (start_time,availability_date,instructor_id,end_time)
VALUES
  ('2:18 PM','Nov 17, 2024',35,'7:14 PM'),
  ('1:55 PM','Feb 22, 2023',32,'7:50 PM'),
  ('2:07 PM','Dec 15, 2024',68,'7:05 PM'),
  ('1:41 PM','Oct 27, 2024',30,'7:21 PM'),
  ('1:32 PM','Jan 23, 2023',64,'7:42 PM'),
  ('2:18 PM','Jul 1, 2023',8,'7:02 PM'),
  ('1:27 PM','Feb 10, 2023',2,'7:26 PM'),
  ('1:12 PM','Jul 2, 2023',71,'7:30 PM'),
  ('1:54 PM','May 16, 2023',47,'7:10 PM'),
  ('2:45 PM','Jun 12, 2024',65,'7:15 PM');
INSERT INTO availability (start_time,availability_date,instructor_id,end_time)
VALUES
  ('1:57 PM','Jan 7, 2024',26,'7:53 PM'),
  ('1:31 PM','May 16, 2024',91,'7:38 PM'),
  ('1:09 PM','Jan 4, 2025',98,'7:44 PM'),
  ('2:23 PM','Nov 21, 2023',43,'7:27 PM'),
  ('2:51 PM','Apr 10, 2024',74,'7:32 PM'),
  ('2:52 PM','Mar 21, 2024',4,'7:50 PM'),
  ('1:41 PM','Jun 19, 2024',37,'7:20 PM'),
  ('1:45 PM','Jul 9, 2023',50,'7:04 PM'),
  ('2:00 PM','Dec 26, 2024',32,'7:02 PM'),
  ('2:08 PM','Dec 16, 2023',81,'7:05 PM');
INSERT INTO availability (start_time,availability_date,instructor_id,end_time)
VALUES
  ('1:20 PM','Mar 21, 2024',24,'7:57 PM'),
  ('1:57 PM','Nov 6, 2024',23,'7:03 PM'),
  ('1:00 PM','Feb 21, 2025',60,'7:22 PM'),
  ('1:08 PM','Dec 18, 2022',40,'7:03 PM'),
  ('1:37 PM','Dec 11, 2022',4,'7:58 PM'),
  ('2:27 PM','Feb 17, 2025',81,'7:12 PM'),
  ('1:06 PM','Jul 7, 2023',6,'7:07 PM'),
  ('1:06 PM','Aug 26, 2023',67,'7:30 PM'),
  ('1:35 PM','May 17, 2023',91,'7:35 PM'),
  ('2:36 PM','Apr 12, 2024',19,'7:41 PM');
INSERT INTO availability (start_time,availability_date,instructor_id,end_time)
VALUES
  ('1:20 PM','May 27, 2023',8,'7:56 PM'),
  ('1:52 PM','Feb 11, 2025',7,'7:55 PM'),
  ('1:53 PM','Mar 6, 2023',69,'7:13 PM'),
  ('2:03 PM','May 16, 2023',8,'7:23 PM'),
  ('2:53 PM','Jan 26, 2024',93,'7:41 PM'),
  ('2:59 PM','Dec 11, 2023',95,'7:16 PM'),
  ('1:12 PM','Jan 24, 2024',71,'7:29 PM'),
  ('1:36 PM','Apr 16, 2023',39,'7:29 PM'),
  ('2:14 PM','Mar 29, 2023',31,'7:19 PM'),
  ('2:38 PM','May 13, 2024',15,'7:54 PM');
INSERT INTO availability (start_time,availability_date,instructor_id,end_time)
VALUES
  ('2:23 PM','Feb 27, 2024',67,'7:20 PM'),
  ('2:08 PM','Mar 9, 2024',14,'7:05 PM'),
  ('1:22 PM','Dec 1, 2022',91,'7:40 PM'),
  ('1:10 PM','Oct 19, 2023',91,'7:09 PM'),
  ('2:03 PM','Apr 7, 2023',74,'7:52 PM'),
  ('1:12 PM','Jul 6, 2024',55,'7:02 PM'),
  ('2:24 PM','Apr 27, 2024',68,'7:49 PM'),
  ('2:22 PM','Aug 29, 2023',89,'7:53 PM'),
  ('1:06 PM','Dec 29, 2023',16,'7:29 PM'),
  ('2:36 PM','Jun 13, 2024',62,'7:48 PM');
INSERT INTO availability (start_time,availability_date,instructor_id,end_time)
VALUES
  ('2:18 PM','Dec 24, 2022',75,'7:34 PM'),
  ('2:12 PM','Dec 31, 2022',33,'7:50 PM'),
  ('1:46 PM','Jun 15, 2023',98,'7:53 PM'),
  ('2:53 PM','Mar 14, 2024',40,'7:40 PM'),
  ('2:47 PM','Feb 18, 2025',49,'7:16 PM'),
  ('2:43 PM','Feb 3, 2023',30,'7:14 PM'),
  ('1:04 PM','Oct 11, 2024',42,'7:46 PM'),
  ('2:37 PM','Nov 17, 2023',11,'7:45 PM'),
  ('1:49 PM','Dec 19, 2024',67,'7:59 PM'),
  ('2:28 PM','Nov 27, 2022',86,'7:38 PM');
INSERT INTO availability (start_time,availability_date,instructor_id,end_time)
VALUES
  ('2:04 PM','Dec 25, 2024',77,'7:33 PM'),
  ('2:54 PM','Nov 30, 2022',3,'7:51 PM'),
  ('2:21 PM','Jul 6, 2024',25,'7:54 PM'),
  ('2:37 PM','Jan 23, 2023',60,'7:17 PM'),
  ('2:46 PM','Aug 16, 2024',52,'7:29 PM'),
  ('2:39 PM','Sep 14, 2024',42,'7:16 PM'),
  ('1:32 PM','Jan 22, 2023',76,'7:07 PM'),
  ('1:19 PM','Oct 14, 2024',26,'7:24 PM'),
  ('1:43 PM','Dec 9, 2024',69,'7:05 PM'),
  ('2:10 PM','Apr 26, 2023',19,'7:15 PM');