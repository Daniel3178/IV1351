INSERT INTO instrument (instrument_id,rent_id,inventory_id)
VALUES
  (1,11,15),
  (2,31,4),
  (3,21,15),
  (4,45,3),
  (5,29,15),
  (6,40,20),
  (7,9,16),
  (8,27,3),
  (9,14,17),
  (10,44,2);
INSERT INTO instrument (instrument_id,rent_id,inventory_id)
VALUES
  (11,37,7),
  (12,40,13),
  (13,2,16),
  (14,6,19),
  (15,16,13),
  (16,8,9),
  (17,42,10),
  (18,49,1),
  (19,14,10),
  (20,30,7);
