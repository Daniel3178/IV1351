INSERT INTO inventory (inventory_id,instrument_type,model,brand,monthly_price,number_of_instrument)
VALUES
  (1,10,'Bongo','Casio','$37.70',14),
  (2,17,'Violin','Focal','$78.70',19),
  (3,17,'Vibraphone','Reed','$84.01',17),
  (4,7,'Saxophone','Warwick','$51.21',14),
  (5,3,'Violin','Baldwin','$68.73',12),
  (6,16,'Organ','Fodera','$92.99',11),
  (7,6,'Synthesizer','Ibanez','$91.27',9),
  (8,9,'Guitar','Yamaha','$21.11',5),
  (9,13,'Cello','Warwick','$96.50',12),
  (10,11,'Clarinet','&','$42.94',11);
INSERT INTO inventory (inventory_id,instrument_type,model,brand,monthly_price,number_of_instrument)
VALUES
  (11,8,'Drum','Ernie','$60.43',14),
  (12,7,'Drum','Moog','$19.09',19),
  (13,10,'Hang','Moog','$84.85',14),
  (14,2,'Piano','Korg','$3.40',12),
  (15,10,'Guitar','Tama','$11.63',15),
  (16,6,'Accordion','Gretsch','$68.17',16),
  (17,13,'Guitar','Sabian','$85.19',17),
  (18,7,'Vibraphone','Marshall','$75.80',9),
  (19,4,'Viola','Yamaha','$94.56',19),
  (20,5,'Tuba','Drums','$21.24',10);
