INSERT INTO ensemble_lesson (ensemble_id,genre,min_number_of_student,max_number_of_student,lesson_id)
VALUES
  (1,'(EDM)',5,23,47),
  (2,'Dance',5,21,44),
  (3,'Jazz',6,20,40),
  (4,'Country',6,23,50),
  (5,'Music',6,23,48),
  (6,'Dance',5,20,46),
  (7,'Hip',5,25,47),
  (8,'(EDM)',6,22,40),
  (9,'Reggae',6,20,43),
  (10,'Jazz',5,24,48);
INSERT INTO ensemble_lesson (ensemble_id,genre,min_number_of_student,max_number_of_student,lesson_id)
VALUES
  (11,'Music',5,21,49),
  (12,'Reggae',5,25,49),
  (13,'Music',6,21,43),
  (14,'Dance',5,24,42),
  (15,'Music',6,21,41),
  (16,'Country',6,23,48),
  (17,'Electronic',6,24,40),
  (18,'Hop',6,22,43),
  (19,'Country',5,21,50),
  (20,'Country',5,21,44);
INSERT INTO ensemble_lesson (ensemble_id,genre,min_number_of_student,max_number_of_student,lesson_id)
VALUES
  (21,'Hip',5,21,47),
  (22,'Country',6,22,45),
  (23,'Music',6,23,49),
  (24,'Electronic',6,22,43),
  (25,'Jazz',6,21,41),
  (26,'Jazz',6,23,43),
  (27,'Hip',5,23,42),
  (28,'Electronic',5,22,43),
  (29,'Reggae',5,23,48),
  (30,'Country',5,23,48);
INSERT INTO ensemble_lesson (ensemble_id,genre,min_number_of_student,max_number_of_student,lesson_id)
VALUES
  (31,'(EDM)',6,24,48),
  (32,'Hop',6,25,46),
  (33,'(EDM)',5,22,46),
  (34,'Electronic',5,22,42),
  (35,'Reggae',6,21,41),
  (36,'Music',6,21,45),
  (37,'Music',5,24,45),
  (38,'Country',5,23,43),
  (39,'Jazz',5,22,44),
  (40,'Electronic',5,23,48);
